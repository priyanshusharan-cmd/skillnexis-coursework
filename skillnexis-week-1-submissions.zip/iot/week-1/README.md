# IoT — Week 1 Smart LED Control

## Concept and architecture

User button → microcontroller GPIO input → firmware state → LED output. A real IoT version could add a network interface and dashboard, but the exercise here is local. Sensors measure physical signals; actuators change them. Analog signals vary continuously; digital signals represent discrete levels.

## Ten applications

Smart thermostats, leak detection, soil moisture irrigation, fleet tracking, industrial predictive maintenance, air-quality monitoring, smart lighting, energy metering, cold-chain temperature logging, and wearable health monitoring.

## Parts and wiring

Arduino-compatible board, LED, 220–330 Ω resistor, push button, jumper wires, breadboard. LED anode → resistor → pin 9; cathode → GND. Button between pin 2 and GND; firmware uses INPUT_PULLUP.

## Practical limitation

No physical board was connected and no hardware screenshots were available. Wiring and behavior are an implementation plan, not a verified build.

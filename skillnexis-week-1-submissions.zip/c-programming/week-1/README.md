# C Programming — Week 1

Solutions for the supplied Week 1 brief: Hello World, sum of two numbers, even/odd check, Fibonacci sequence, and a simple calculator using `switch`.

## Run

Compile with a C11 compiler, then run the executable:

```sh
cc -std=c11 -Wall -Wextra -pedantic main.c -o week1
./week1
```

The program uses small input-reading helpers so invalid numeric input is handled without leaving a bad value in the input buffer.

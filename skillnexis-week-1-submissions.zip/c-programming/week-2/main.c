#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_ARRAY_SIZE 100
#define MAX_MATRIX_SIZE 10

static int read_line(char *buffer, size_t size) {
    if (fgets(buffer, (int)size, stdin) == NULL) return 0;
    size_t length = strlen(buffer);
    if (length > 0 && buffer[length - 1] == '\n') {
        buffer[length - 1] = '\0';
    } else {
        int character;
        while ((character = getchar()) != '\n' && character != EOF) {
        }
    }
    return 1;
}

static int read_int(const char *prompt, int *value) {
    char line[128];
    char *end = NULL;
    printf("%s", prompt);
    if (!read_line(line, sizeof line)) return 0;

    errno = 0;
    long parsed = strtol(line, &end, 10);
    while (end != NULL && isspace((unsigned char)*end)) end++;
    if (errno != 0 || end == line || *end != '\0' || parsed < INT_MIN || parsed > INT_MAX) {
        printf("Please enter a whole number.\n");
        return -1;
    }
    *value = (int)parsed;
    return 1;
}

static int read_bounded_int(const char *prompt, int minimum, int maximum, int *value) {
    for (;;) {
        int status = read_int(prompt, value);
        if (status <= 0) return status;
        if (*value >= minimum && *value <= maximum) return 1;
        printf("Enter a value from %d to %d.\n", minimum, maximum);
    }
}

static int read_array(int values[], int *length) {
    int status = read_bounded_int("Number of elements (1-100): ", 1, MAX_ARRAY_SIZE, length);
    if (status <= 0) return status;
    for (int index = 0; index < *length; index++) {
        char prompt[64];
        snprintf(prompt, sizeof prompt, "Element %d: ", index + 1);
        status = read_int(prompt, &values[index]);
        if (status <= 0) return status;
        if (status < 0) index--;
    }
    return 1;
}

static void find_largest_element(void) {
    int values[MAX_ARRAY_SIZE];
    int length;
    if (read_array(values, &length) <= 0) return;

    int largest = values[0];
    for (int index = 1; index < length; index++) {
        if (values[index] > largest) largest = values[index];
    }
    printf("Largest element: %d\n", largest);
}

static void count_positive_and_negative(void) {
    int values[MAX_ARRAY_SIZE];
    int length;
    if (read_array(values, &length) <= 0) return;

    int positive = 0;
    int negative = 0;
    int zero = 0;
    for (int index = 0; index < length; index++) {
        if (values[index] > 0) positive++;
        else if (values[index] < 0) negative++;
        else zero++;
    }
    printf("Positive: %d\nNegative: %d\nZero: %d\n", positive, negative, zero);
}

static unsigned long long factorial(unsigned int number) {
    if (number <= 1U) return 1ULL;
    return (unsigned long long)number * factorial(number - 1U);
}

static void show_factorial(void) {
    int number;
    if (read_bounded_int("Enter a whole number (0-20): ", 0, 20, &number) <= 0) return;
    printf("%d! = %llu\n", number, factorial((unsigned int)number));
}

static void add_two_matrices(void) {
    int first[MAX_MATRIX_SIZE][MAX_MATRIX_SIZE];
    int second[MAX_MATRIX_SIZE][MAX_MATRIX_SIZE];
    long long sum[MAX_MATRIX_SIZE][MAX_MATRIX_SIZE];
    int rows;
    int columns;
    int status = read_bounded_int("Rows (1-10): ", 1, MAX_MATRIX_SIZE, &rows);
    if (status <= 0) return;
    status = read_bounded_int("Columns (1-10): ", 1, MAX_MATRIX_SIZE, &columns);
    if (status <= 0) return;

    printf("Enter the first matrix:\n");
    for (int row = 0; row < rows; row++) {
        for (int column = 0; column < columns; column++) {
            char prompt[80];
            snprintf(prompt, sizeof prompt, "A[%d][%d]: ", row + 1, column + 1);
            if (read_int(prompt, &first[row][column]) <= 0) return;
        }
    }

    printf("Enter the second matrix:\n");
    for (int row = 0; row < rows; row++) {
        for (int column = 0; column < columns; column++) {
            char prompt[80];
            snprintf(prompt, sizeof prompt, "B[%d][%d]: ", row + 1, column + 1);
            if (read_int(prompt, &second[row][column]) <= 0) return;
        }
    }

    printf("Sum matrix:\n");
    for (int row = 0; row < rows; row++) {
        for (int column = 0; column < columns; column++) {
            sum[row][column] = (long long)first[row][column] + second[row][column];
            printf("%lld%s", sum[row][column], column + 1 == columns ? "\n" : "\t");
        }
    }
}

static double calculate_average(const int marks[], int count) {
    int total = 0;
    for (int index = 0; index < count; index++) total += marks[index];
    return (double)total / count;
}

static void student_average_calculator(void) {
    int marks[MAX_ARRAY_SIZE];
    int count;
    if (read_bounded_int("Number of subjects (1-100): ", 1, MAX_ARRAY_SIZE, &count) <= 0) return;

    for (int index = 0; index < count; index++) {
        char prompt[80];
        snprintf(prompt, sizeof prompt, "Mark for subject %d (0-100): ", index + 1);
        if (read_bounded_int(prompt, 0, 100, &marks[index]) <= 0) return;
    }
    printf("Student average: %.2f%%\n", calculate_average(marks, count));
}

int main(void) {
    for (;;) {
        int choice;
        printf("\nC Programming — Week 2: Arrays & Functions\n");
        printf("1) Find largest element in an array\n");
        printf("2) Count positive, negative, and zero values\n");
        printf("3) Calculate factorial using a function\n");
        printf("4) Add two matrices\n");
        printf("5) Student average calculator\n");
        printf("6) Exit\n");

        int status = read_int("Choose an option: ", &choice);
        if (status == 0) return 0;
        if (status < 0) continue;
        switch (choice) {
            case 1: find_largest_element(); break;
            case 2: count_positive_and_negative(); break;
            case 3: show_factorial(); break;
            case 4: add_two_matrices(); break;
            case 5: student_average_calculator(); break;
            case 6: return 0;
            default: printf("Choose a number from 1 to 6.\n");
        }
    }
}

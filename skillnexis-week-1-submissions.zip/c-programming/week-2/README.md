# C Programming — Week 2

Solutions for the supplied Week 2 brief on arrays and functions: largest array element, positive/negative counts, factorial, matrix addition, and a student average calculator.

## Run

Compile with a C11 compiler, then run the executable:

```sh
cc -std=c11 -Wall -Wextra -pedantic main.c -o week2
./week2
```

The menu keeps each assignment separate. Inputs are checked, array and matrix sizes are bounded, and factorial accepts values from 0 through 20 to fit in `unsigned long long`.

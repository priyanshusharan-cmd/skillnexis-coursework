# GenAI & LLM Development — Week 1

## Concepts

A token is a model’s text unit; a context window is the maximum input/output token span; inference is generating outputs from a trained model; hallucination is plausible output unsupported by evidence. Prompting changes the request at inference time. RAG retrieves external passages and supplies them as context. Fine-tuning changes model parameters using additional training examples.

## Prompt patterns

- **Summarize:** “Summarize the supplied text in 3 bullets. Use only facts stated in it; preserve names and numbers.”
- **Extract:** “Return the invoice date, vendor, and total as JSON. Use null when a field is absent.”
- **Classify:** “Classify the message as billing, technical, or other. Return one label and a one-sentence rationale.”
- **Question answering:** “Answer only from the provided passage. Quote the supporting sentence; if absent, say ‘Not stated.’”

## Evaluation protocol

For each of ten examples, record input, baseline prompt/output, improved prompt/output, reference answer, factual correctness, instruction following, and error notes. No model output was generated in this workspace, so no evaluation scores are fabricated.

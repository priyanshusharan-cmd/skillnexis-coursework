# Generative AI & LLM Development — Week 1

Includes concept notes, prompt templates, an optional local Hugging Face summarizer, and a ten-example evaluation worksheet. First model run may download weights and requires internet. The five-example factuality review and ten-prompt comparison must be completed by running a model and checking outputs against source texts; no model results are invented.

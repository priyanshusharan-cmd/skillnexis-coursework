# Game Developer — Week 1

Includes the one-page GDD and a minimal Unity movement/score/health script. Create a 2D Unity scene, attach `PlayerController.cs` to a player object, add colliders and trigger scripts for pickups/hazards, then implement timer/UI and test in Unity. This repo does not include the Unity editor project or claim a working build.

# Flutter — Week 1

`lib/main.dart` supplies the Hello Flutter heading and responsive profile card/personal info screen with built-in Material icons (no photo asset supplied). Create a Flutter project with `flutter create app`, replace `lib/main.dart`, then run `flutter run`. Replace sample identity/contact details and add an authorized photo before submission. Not built here.

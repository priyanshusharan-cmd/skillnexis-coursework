# SkillNexis Coursework

Week 1 assignment work is grouped by course under `<course>/week-1/`; C and Python also include Week 2 from earlier submissions. Do not include downloaded course ZIPs or copied lecture notes here.

## Week 1 folders

- `c-programming`, `cpp-programming`, `python`, `java`, `web-development`, `mern`
- `data-analyst`, `data-science-python`, `machine-learning-ai`, `power-bi`, `dsa`
- `flutter`, `aws-cloud`, `game-development`, `qa-testing`, `digital-marketing`, `video-editing`
- `iot`, `ui-ux`, `deep-learning`, `generative-ai-llm`

## Completion notes

Some briefs require external resources the downloads did not include. Synthetic CSVs are labeled as synthetic; the Data Science pack duplicates and labels itself as Data Analyst; QA has no demo-site URL; AWS account/bucket actions were documented as a safe plan; IoT hardware and video footage were not available; Unity and Flutter builds were not run; model inference/evaluation was not run. These folders contain preparation artifacts where hands-on evidence remains necessary.

Course platform submissions are separate from these local files.

# Software QA Tester — Week 1

Login test cases and a bug-report template are included. The course brief asks to find defects in a demo website but provides no URL or build, so all cases are explicitly marked not executed. Add real observations and evidence after testing the assigned target.

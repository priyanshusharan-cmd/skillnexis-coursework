# Python Programming — Week 1

Solutions for the Week 1 Python Basics assignments and practice questions in the supplied course pack.

## Files

- `assignments.py`: temperature converter, student grade calculator, even/odd and prime checker, and a function-based ATM simulator.
- `practice.py`: circle area, even/odd, recursive factorial, vowel/consonant counter, and Fibonacci sequence.

## Run

Use Python 3.10 or newer:

```sh
python3 assignments.py
python3 practice.py
```

The ATM is a local demonstration only. Its sample PIN is `1234`; do not use a real PIN. The balance resets each time the program starts.

## Grade bands

The grade calculator uses these simple example bands: A = 90–100, B = 80–89, C = 70–79, D = 60–69, F = below 60. Each mark must be between 0 and 100.

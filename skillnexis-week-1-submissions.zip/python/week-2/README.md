# Python — Week 2

Solutions for the Week 2 data structures and file handling brief.

## Files

- `assignments.py`: dictionary contact book, text-file word counter, JSON reader, and CSV-backed student manager.
- `practice.py`: list CRUD, word frequencies, nested-loop pattern, list extrema, and sorting with a lambda key.

## Run

```sh
python3 assignments.py
python3 practice.py
```

The student manager stores `students.csv` beside the script. The JSON reader accepts a path to an existing JSON file.
